using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace weterynarz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            System.Object[] ItemObject = new System.Object[3];
            ItemObject[0] = "pies";
            ItemObject[1] = "kot";
            ItemObject[2] = "swinkaMorska";
            listaGatunkow.Items.AddRange(ItemObject);
        }

        private void wiekSuwak_Scroll(object sender, EventArgs e)
        {
            wiek.Text = wiekSuwak.Value.ToString();
        }

        private void przycisk_Click(object sender, EventArgs e)
        {
            wynikZadania.Text = "imie i nazwisko: " + imie.Text + "\nGatunek: " + listaGatunkow.Text + "\nWiek: " + wiekSuwak.Value + "\ncel: " + cel.Text + "\nGodzina wizyty:" + godzina.Text;
            MessageBox.Show("imie i nazwisko: " + imie.Text + "\nGatunek: " + listaGatunkow.Text + "\nWiek: " + wiekSuwak.Value + "\ncel: " + cel.Text + "\nGodzina wizyty:" + godzina.Text);
        }

        private void listaGatunkow_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listaGatunkow.Text == "pies")
            {
                wiekSuwak.Maximum = 18;
            }
            else if (listaGatunkow.Text == "kot")
            {
                wiekSuwak.Maximum = 20;

            }
            else if (listaGatunkow.Text == "swinkaMorska")
            {
                wiekSuwak.Maximum = 9;
            }
        }
    }
}
