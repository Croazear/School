﻿namespace weterynarz
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            imie = new TextBox();
            gatunek = new Label();
            listaGatunkow = new ComboBox();
            label2 = new Label();
            wiek = new Label();
            wiekSuwak = new TrackBar();
            cel = new TextBox();
            godzina = new TextBox();
            przycisk = new Button();
            wynikZadania = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)wiekSuwak).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(360, 18);
            label1.Name = "label1";
            label1.Size = new Size(120, 15);
            label1.TabIndex = 0;
            label1.Text = "Wizyta u Weterynarza";
            // 
            // imie
            // 
            imie.Location = new Point(252, 49);
            imie.Name = "imie";
            imie.PlaceholderText = "Imię i nazwisko wlaściciela";
            imie.Size = new Size(332, 23);
            imie.TabIndex = 1;
            // 
            // gatunek
            // 
            gatunek.AutoSize = true;
            gatunek.Location = new Point(252, 92);
            gatunek.Name = "gatunek";
            gatunek.Size = new Size(51, 15);
            gatunek.TabIndex = 2;
            gatunek.Text = "Gatunek";
            // 
            // listaGatunkow
            // 
            listaGatunkow.FormattingEnabled = true;
            listaGatunkow.Location = new Point(252, 110);
            listaGatunkow.Name = "listaGatunkow";
            listaGatunkow.Size = new Size(121, 23);
            listaGatunkow.TabIndex = 3;
            listaGatunkow.SelectedIndexChanged += listaGatunkow_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(254, 151);
            label2.Name = "label2";
            label2.Size = new Size(60, 15);
            label2.TabIndex = 4;
            label2.Text = "ile ma lat?";
            // 
            // wiek
            // 
            wiek.AutoSize = true;
            wiek.Location = new Point(320, 151);
            wiek.Name = "wiek";
            wiek.Size = new Size(13, 15);
            wiek.TabIndex = 5;
            wiek.Text = "0";
            // 
            // wiekSuwak
            // 
            wiekSuwak.LargeChange = 2;
            wiekSuwak.Location = new Point(376, 142);
            wiekSuwak.Maximum = 20;
            wiekSuwak.Name = "wiekSuwak";
            wiekSuwak.Size = new Size(208, 45);
            wiekSuwak.TabIndex = 6;
            wiekSuwak.Scroll += wiekSuwak_Scroll;
            // 
            // cel
            // 
            cel.Location = new Point(252, 193);
            cel.Name = "cel";
            cel.PlaceholderText = "Cel wizyty";
            cel.Size = new Size(332, 23);
            cel.TabIndex = 7;
            // 
            // godzina
            // 
            godzina.Location = new Point(252, 232);
            godzina.Name = "godzina";
            godzina.PlaceholderText = "16:00";
            godzina.Size = new Size(332, 23);
            godzina.TabIndex = 8;
            godzina.Text = "16:00";
            // 
            // przycisk
            // 
            przycisk.BackColor = Color.Purple;
            przycisk.ForeColor = Color.Snow;
            przycisk.Location = new Point(254, 280);
            przycisk.Name = "przycisk";
            przycisk.Size = new Size(330, 23);
            przycisk.TabIndex = 9;
            przycisk.Text = "OK";
            przycisk.UseVisualStyleBackColor = false;
            przycisk.Click += przycisk_Click;
            // 
            // wynikZadania
            // 
            wynikZadania.AutoSize = true;
            wynikZadania.Location = new Point(360, 331);
            wynikZadania.Name = "wynikZadania";
            wynikZadania.Size = new Size(0, 15);
            wynikZadania.TabIndex = 10;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(254, 31);
            label3.Name = "label3";
            label3.Size = new Size(87, 15);
            label3.TabIndex = 11;
            label3.Text = "Imie i nazwisko";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(128, 255, 128);
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(wynikZadania);
            Controls.Add(przycisk);
            Controls.Add(godzina);
            Controls.Add(cel);
            Controls.Add(wiekSuwak);
            Controls.Add(wiek);
            Controls.Add(label2);
            Controls.Add(listaGatunkow);
            Controls.Add(gatunek);
            Controls.Add(imie);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)wiekSuwak).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox imie;
        private Label gatunek;
        private ComboBox listaGatunkow;
        private Label label2;
        private Label wiek;
        private TrackBar wiekSuwak;
        private TextBox cel;
        private TextBox godzina;
        private Button przycisk;
        private Label wynikZadania;
        private Label label3;
    }
}
